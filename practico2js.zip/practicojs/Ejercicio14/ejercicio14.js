function mostrarTareas() {
    const listaTareas = document.getElementById('listaTareas');
    listaTareas.innerHTML = '';

    const tareas = JSON.parse(localStorage.getItem('tareas')) || [];

    tareas.forEach(tarea => {
        const li = document.createElement('li');
        li.textContent = tarea;
        listaTareas.appendChild(li);
    });
}

window.onload = mostrarTareas;

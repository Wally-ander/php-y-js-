function guardarDatos(event) {
    event.preventDefault();

    const nombre = document.getElementById('nombre').value.trim();
    const edad = document.getElementById('edad').value.trim();

    if (nombre === '' || edad === '') {
        alert('Por favor, completa todos los campos.');
        return;
    }

    const persona = {
        nombre: nombre,
        edad: parseInt(edad)
    };

    localStorage.setItem('persona', JSON.stringify(persona));

    mostrarDatos();
}

function mostrarDatos() {
    const datosGuardados = localStorage.getItem('persona');

    if (datosGuardados) {
        const persona = JSON.parse(datosGuardados);
        document.getElementById('resultado').innerHTML = `
            <h2>Datos Guardados</h2>
            <p><strong>Nombre:</strong> ${persona.nombre}</p>
            <p><strong>Edad:</strong> ${persona.edad}</p>
        `;
    }
}

window.onload = function() {
    mostrarDatos();
};

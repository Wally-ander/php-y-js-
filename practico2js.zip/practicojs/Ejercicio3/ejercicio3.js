
// Usando un bucle for
for (let i = 1; i <= 10; i++) {
    console.log(i);
}

// Usando un bucle while
let i = 1;
while (i <= 10) {
    console.log(i);
    i++;
}

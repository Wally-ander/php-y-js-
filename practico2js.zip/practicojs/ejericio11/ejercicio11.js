function Persona(nombre, edad, ci) {
    this.nombre = nombre;
    this.edad = edad;
    this.ci = ci;
}


Persona.prototype.saludo = function() {
    return `Hola, soy ${this.nombre}, tengo ${this.edad} años y mi cédula es ${this.ci}.`;
};


function Estudiante(nombre, edad, ci, curso) {
  
    Persona.call(this, nombre, edad, ci);
    this.curso = curso;
}


Estudiante.prototype = Object.create(Persona.prototype);
Estudiante.prototype.constructor = Estudiante;


Estudiante.prototype.saludoEstudiante = function() {
    return `${this.saludo()} Estoy cursando: ${this.curso}.`;
};


const estudiante1 = new Estudiante("María antonieta de las nieves", 22, "12345678", "Programación");


document.body.innerHTML += `
    <h2>Datos del Estudiante</h2>
    <p>${estudiante1.saludoEstudiante()}</p>
`;

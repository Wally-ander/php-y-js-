class Agenda {
    constructor() {
        this.contactos = JSON.parse(localStorage.getItem('contactos')) || [];
    }

    agregarContacto(contacto) {
        this.contactos.push(contacto);
        localStorage.setItem('contactos', JSON.stringify(this.contactos));
        this.mostrarContactos();
    }

    eliminarContacto(index) {
        this.contactos.splice(index, 1);
        localStorage.setItem('contactos', JSON.stringify(this.contactos));
        this.mostrarContactos();
    }

    mostrarContactos() {
        const listaContactos = document.getElementById('listaContactos');
        listaContactos.innerHTML = '';
        
        this.contactos.forEach((contacto, index) => {
            const li = document.createElement('li');
            li.innerHTML = `
                ${contacto.nombre} - ${contacto.telefono} - ${contacto.email} 
                <button onclick="agenda.eliminarContacto(${index})">Eliminar</button>
            `;
            listaContactos.appendChild(li);
        });
    }
}

const agenda = new Agenda();

document.getElementById('formulario').addEventListener('submit', (event) => {
    event.preventDefault();

    const nombre = document.getElementById('nombre').value.trim();
    const telefono = document.getElementById('telefono').value.trim();
    const email = document.getElementById('email').value.trim();

    if (nombre === '' || telefono === '' || email === '') {
        alert('Por favor, completa todos los campos.');
        return;
    }

    const contacto = { nombre, telefono, email };
    agenda.agregarContacto(contacto);

    document.getElementById('formulario').reset();
});

window.onload = () => agenda.mostrarContactos();

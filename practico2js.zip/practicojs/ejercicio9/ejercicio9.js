function Persona(nombre, edad) {
    this.nombre = nombre;
    this.edad = edad;

    let ciPrivado = "";

    
    this.agregarCi = function(nuevoCi) {
        ciPrivado = nuevoCi;
    };

  
    this.verCi = function() {
        return ciPrivado;
    };
}


const persona1 = new Persona("Carlos", 25);


persona1.agregarCi("58472910");


console.log("Nombre:", persona1.nombre);
console.log("Edad:", persona1.edad);
console.log("CI (oculta):", persona1.verCi());


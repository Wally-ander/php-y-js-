
function esPar() {
    let numero = prompt('Ingresa un número:');
    numero = parseInt(numero);
    
    if (numero % 2 === 0) {
        console.log(true);
    } else {
        console.log(false);
    }
}

esPar();

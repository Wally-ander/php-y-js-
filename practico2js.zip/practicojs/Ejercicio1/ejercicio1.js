
let nombre = 'Juan';
let edad = 25;
let esEstudiante = true;

console.log('Nombre:', nombre);
console.log('Edad:', edad);
console.log('Es estudiante:', esEstudiante);

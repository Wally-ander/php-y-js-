function agregarTarea(event) {
    event.preventDefault();

    const tarea = document.getElementById('tarea').value.trim();

    if (tarea === '') {
        alert('Por favor, ingresa una tarea.');
        return;
    }

    let tareas = JSON.parse(localStorage.getItem('tareas')) || [];
    tareas.push(tarea);
    localStorage.setItem('tareas', JSON.stringify(tareas));

    mostrarTareas();
}

function mostrarTareas() {
    const listaTareas = document.getElementById('listaTareas');
    listaTareas.innerHTML = '';

    const tareas = JSON.parse(localStorage.getItem('tareas')) || [];
    tareas.forEach(tarea => {
        const li = document.createElement('li');
        li.textContent = tarea;
        listaTareas.appendChild(li);
    });
}

document.getElementById('formulario').addEventListener('submit', agregarTarea);

window.onload = mostrarTareas;

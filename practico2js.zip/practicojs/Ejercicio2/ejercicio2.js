
let edad = prompt('Por favor subnormal , ingresa tu edad:');
edad = parseInt(edad);

if (edad < 18) {
    alert('Eres menor de edad imbecil');
} else if (edad === 18) {
    alert('Tienes exactamente 18 años ');
} else {
    alert('Eres mayor de edad muy bien ');
}

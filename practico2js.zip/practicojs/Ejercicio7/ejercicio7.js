
let formulario = document.createElement('form');
let input = document.createElement('input');
input.type = 'text';
formulario.appendChild(input);

let boton = document.createElement('button');
boton.textContent = 'Mostrar texto';
formulario.appendChild(boton);

document.body.appendChild(formulario);

boton.addEventListener('click', (event) => {
    event.preventDefault();
    let parrafo = document.createElement('p');
    parrafo.textContent = input.value;
    document.body.appendChild(parrafo);
});

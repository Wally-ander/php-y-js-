
let boton = document.createElement('button');
boton.textContent = 'Haz clic aquí';
document.body.appendChild(boton);

boton.addEventListener('click', () => {
    alert('¡Hola desde JavaScript!');
});

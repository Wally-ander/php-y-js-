function Persona(nombre, edad, ci) {
    this.nombre = nombre;
    this.edad = edad;
    this.ci = ci;

   
    this.saludo = function() {
        return `Hola, soy ${this.nombre}, tengo ${this.edad} años y mi cédula es ${this.ci}.`;
    };
}


const persona1 = new Persona("Lucía", 20, "12345678");
const persona2 = new Persona("Martín", 30, "87654321");


document.body.innerHTML += `
    <h2>Saludos de Personas</h2>
    <p>${persona1.saludo()}</p>
    <p>${persona2.saludo()}</p>
`;

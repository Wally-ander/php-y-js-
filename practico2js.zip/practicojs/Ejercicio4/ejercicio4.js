
let colores = ['Rojo', 'Azul', 'Verde', 'Amarillo', 'Naranja'];

// Usando un bucle for
for (let i = 0; i < colores.length; i++) {
    console.log(colores[i]);
}

// Usando un bucle forEach
colores.forEach(color => {
    console.log(color);
});

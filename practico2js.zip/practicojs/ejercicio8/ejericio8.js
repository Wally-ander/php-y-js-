const formulario = document.getElementById('formulario');
const mensaje = document.getElementById('mensaje');

formulario.addEventListener('submit', function(e) {
    e.preventDefault(); 

    const nombre = document.getElementById('nombre').value.trim();
    const edad = parseInt(document.getElementById('edad').value);
    const cedula = document.getElementById('cedula').value.trim();

    if (nombre === '') {
        mensaje.textContent = 'El nombre no puede estar vacío.';
        mensaje.style.color = 'red';
    } else if (isNaN(edad) || edad <= 0) {
        mensaje.textContent = 'La edad debe ser mayor a 0.';
        mensaje.style.color = 'red';
    } else if (cedula === '') {
        mensaje.textContent = 'La cédula no puede estar vacía.';
        mensaje.style.color = 'red';
    } else {
        mensaje.textContent = `Formulario enviado correctamente: ${nombre}, ${edad} años, CI: ${cedula}`;
        mensaje.style.color = 'green';
    }
});

<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nombre = $_POST['Nombre'];
    $edad = $_POST['Edad'];
    $cedula = $_POST['Cedula'];

    $Mnombre = ucfirst($nombre);

    class Persona {
        public $nombre;
        public $edad;
        public $cedula;

        public function __construct($Mnombre, $edad, $cedula) {
            $this->nombre = $Mnombre;
            $this->edad = $edad;
            $this->cedula = $cedula;
        } 

        public function saludar() {
            return "Hola, mi nombre es " . $this->nombre . ", tengo " . $this->edad . " años y mi cédula es " . $this->cedula . ".";
        }
        
    }

    $persona = new Persona(
        $Mnombre,
        $edad,
        $cedula
    );

    echo $persona->saludar();
}
?>

<?php
require_once 'Contacto.php';

class Agenda {
    private $archivo = 'contactos.txt';

    public function agregarContacto(Contacto $contacto) {
        $datos = $contacto->toArray();
        $linea = implode('|', $datos) . "\n";
        file_put_contents($this->archivo, $linea, FILE_APPEND);
    }

    public function listarContactos() {
        if (!file_exists($this->archivo)) {
            echo "No hay contactos guardados.<br>";
            return;
        }

        $contenido = file($this->archivo, FILE_IGNORE_NEW_LINES);
        foreach ($contenido as $linea) {
            list($nombre, $edad, $ci, $telefono, $email) = explode('|', $linea);
            echo "Nombre: $nombre, Edad: $edad, CI: $ci, Teléfono: $telefono, Email: $email<br>";
        }
    }

    public function eliminarContacto($nombreBuscar) {
        if (!file_exists($this->archivo)) {
            echo "No hay contactos guardados.<br>";
            return;
        }

        $contenido = file($this->archivo, FILE_IGNORE_NEW_LINES);
        $nuevoContenido = '';

        foreach ($contenido as $linea) {
            list($nombre, $edad, $ci, $telefono, $email) = explode('|', $linea);
            if (strtolower($nombre) !== strtolower($nombreBuscar)) {
                $nuevoContenido .= $linea . "\n";
            }
        }

        file_put_contents($this->archivo, $nuevoContenido);
        echo "Contacto '$nombreBuscar' eliminado (si existía).<br>";
    }
}
?>

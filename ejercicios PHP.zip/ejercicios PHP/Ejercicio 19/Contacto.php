<?php
class Persona {
    protected $nombre;
    protected $edad;
    protected $ci;

    public function __construct($nombre, $edad, $ci) {
        $this->nombre = $nombre;
        $this->edad = $edad;
        $this->ci = $ci;
    }

    public function getNombre() {
        return $this->nombre;
    }

    public function getEdad() {
        return $this->edad;
    }

    public function getCi() {
        return $this->ci;
    }
}

class Contacto extends Persona {
    private $telefono;
    private $email;

    public function __construct($nombre, $edad, $ci, $telefono, $email) {
        parent::__construct($nombre, $edad, $ci);
        $this->telefono = $telefono;
        $this->email = $email;
    }

    public function getTelefono() {
        return $this->telefono;
    }

    public function getEmail() {
        return $this->email;
    }

    public function toArray() {
        return [
            'nombre' => $this->nombre,
            'edad' => $this->edad,
            'ci' => $this->ci,
            'telefono' => $this->telefono,
            'email' => $this->email
        ];
    }
}
?>

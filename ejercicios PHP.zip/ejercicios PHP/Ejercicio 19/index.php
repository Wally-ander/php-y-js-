<?php
require_once 'Agenda.php';

$agenda = new Agenda();

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_POST['accion'])) {
        if ($_POST['accion'] == 'agregar') {
            $nombre = trim($_POST['nombre']);
            $edad = (int) $_POST['edad'];
            $ci = trim($_POST['ci']);
            $telefono = trim($_POST['telefono']);
            $email = trim($_POST['email']);

            if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
                echo "Email no válido.<br>";
            } else {
                $contacto = new Contacto($nombre, $edad, $ci, $telefono, $email);
                $agenda->agregarContacto($contacto);
                echo "Contacto agregado exitosamente.<br>";
            }
        } elseif ($_POST['accion'] == 'eliminar') {
            $nombreEliminar = trim($_POST['nombre_eliminar']);
            $agenda->eliminarContacto($nombreEliminar);
        }
    }
}
?>

<h2>Agregar Contacto</h2>
<form method="post">
    <input type="hidden" name="accion" value="agregar">
    Nombre: <input type="text" name="nombre" required><br>
    Edad: <input type="number" name="edad" required><br>
    CI: <input type="text" name="ci" required><br>
    Teléfono: <input type="text" name="telefono" required><br>
    Email: <input type="email" name="email" required><br>
    <input type="submit" value="Agregar Contacto">
</form>

<h2>Eliminar Contacto</h2>
<form method="post">
    <input type="hidden" name="accion" value="eliminar">
    Nombre del contacto a eliminar: <input type="text" name="nombre_eliminar" required><br>
    <input type="submit" value="Eliminar Contacto">
</form>

<h2>Lista de Contactos</h2>
<?php
$agenda->listarContactos();
?>

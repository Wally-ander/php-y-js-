<?php
    $numero = $_POST['numero'];

    $numeroF = (int)$numero; // Convertir a entero

    echo ("El número original es: $numero");
    echo ("<br>");
    echo ("El número convertido a entero es: $numeroF <br>");
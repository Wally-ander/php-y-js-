<?php
if (file_exists('funciones.php')) {
    require 'funciones.php';
} else {
    die('El archivo funciones.php no existe.');
}

include 'datos.php';

mostrarUsuarios($usuarios);

echo "<br>";

modificarUsuario($usuarios, 0, 'Carlos', 'Gomez', 35);
mostrarUsuarios($usuarios);
echo "<br>";
modificarUsuario($usuarios, 1, 'Ana', 'Martinez', 28);
mostrarUsuarios($usuarios);
echo "<br>";


?>




?>  
<?php

function mostrarUsuarios($usuarios) {
    foreach ($usuarios as  $indice => $usuario) {
        echo "Usuario #" . ($indice + 1) . "<br>";
        echo "Nombre completo: " . $usuario['nombre'] . " " . $usuario['apellidos'] . "<br>";
        echo "Edad: " . $usuario['edad'] . " años <br><br>";  
    }
}

function modificarUsuario(&$usuarios, $indice, $nuevoNombre, $nuevosApellidos, $nuevaEdad) {
    if (isset($usuarios[$indice])) {
        $usuarios[$indice]['nombre'] = $nuevoNombre;
        $usuarios[$indice]['apellidos'] = $nuevosApellidos;
        $usuarios[$indice]['edad'] = $nuevaEdad;
    } else {
        echo "Error: Usuario no encontrado.<br>";
    }
}

?>
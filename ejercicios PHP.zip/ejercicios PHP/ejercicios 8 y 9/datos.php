<?php

$usuarios = [
    [
        'nombre' => 'juan',
        'apellidos' => 'perez',
        'edad' => 25,
    ],
    [
        'nombre' => 'maria',
        'apellidos' => 'lopez',
        'edad' => 30,
    ]
]
?>
<?php
    // Recibe los datos enviados desde el formulario (Nombre y Edad)
    $Nombre = $_POST["Nombre"];
    $Edad = $_POST["Edad"];

    // Calcula la edad en 5 años
    $Resultado = $Edad + 5;

    // Muestra un mensaje con el nombre, edad actual y edad futura
    echo( "Hola $Nombre, tienes $Edad años y en 5 años tendrás $Resultado años.");
?>
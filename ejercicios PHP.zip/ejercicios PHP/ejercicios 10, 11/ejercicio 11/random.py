import random

# Genera un número aleatorio entre 10000000 y 99999999
numero = random.randint(10000000, 99999999)

print("El número aleatorio es: " + str(numero))


numero2 = random.randint(10000000, 99999999)
print("El segundo número aleatorio es: " + str(numero2))

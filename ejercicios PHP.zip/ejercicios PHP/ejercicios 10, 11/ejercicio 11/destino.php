<?php

// Si el formulario de actualización fue enviado
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['actualizar'])) {
    // Recibir la nueva cédula
    $nuevoCi = $_POST['nuevoCedula'];

    // Actualizar la cédula
    $persona->actualizarCi($nuevoCi);

    // Mostrar mensaje de que la cédula fue actualizada
    echo "La cédula ha sido actualizada a: " . $persona->verCi() . "<br>";
}

if ($_SERVER["REQUEST_METHOD"] == "POST" && !isset($_POST['actualizar'])) {
    // Recibir los datos del primer formulario
    $nombre = $_POST['nombre'];
    $edad = $_POST['edad'];
    $cedula = $_POST['cedula'];

    // Asegurarse de capitalizar el nombre
    $Mnombre = ucfirst($nombre);

    // Crear la clase Persona
    class Persona {
        public $nombre;
        public $edad;
        private $ci;  // Atributo privado para cédula (encapsulamiento)

        // Constructor para inicializar los datos
        public function __construct($Mnombre, $edad) {
            $this->nombre = $Mnombre;
            $this->edad = $edad;
        }

        // Método público para actualizar la cédula
        public function actualizarCi($nuevoCi) {
            $this->ci = $nuevoCi;  // Asignar nueva cédula
        }

        // Método público para obtener la cédula
        public function verCi() {
            return $this->ci;  // Devolver cédula
        }

        // Método para saludar
        public function saludar() {
            return "Hola, mi nombre es " . $this->nombre . ", tengo " . $this->edad . " años y mi cédula es " . $this->verCi() . ".";
        }
    }

    // Crear el objeto Persona
    $persona = new Persona($Mnombre, $edad);

    // Asignar la cédula inicial
    $persona->actualizarCi($cedula);

    // Mostrar saludo
    echo $persona->saludar();
?>

<!-- Mostrar formulario para actualizar la cédula después del saludo -->
<form method="POST">
    <label for="nuevoCedula">Nueva Cédula:</label>
    <input type="text" name="nuevoCedula" required><br>
    <button type="submit" name="actualizar">Actualizar Cédula</button>
</form>

<?php
}
else {
    // Si el formulario no ha sido enviado, mostrar el primer formulario
    ?>

    <form method="POST">
        <label for="nombre">Nombre:</label>
        <input type="text" name="nombre" required><br>

        <label for="edad">Edad:</label>
        <input type="number" name="edad" required><br>

        <label for="cedula">Cédula:</label>
        <input type="text" name="cedula" required><br>

        <button type="submit">Enviar</button>
    </form>

    <?php
}
?>

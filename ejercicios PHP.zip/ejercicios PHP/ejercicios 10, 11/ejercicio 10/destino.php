<?php
    
    $nombre = $_POST['nombre'];
    $edad = $_POST['edad'];
    $cedula = $_POST['cedula'];


    $Mnombre = ucfirst($nombre);

    class Persona {
        public $nombre;
        public $edad;
        public $cedula;

        public function __construct($Mnombre, $edad) {
            $this->nombre = $Mnombre;
            $this->edad = $edad;
            $this->cedula = $cedula;
        }

        public function saludar() {
            return "Hola, mi nombre es " . $this->nombre . ", tengo " . $this->edad . " años y" . " mi cédula es " . $this->cedula . ".";
        }
    }

    $persona = new Persona(
        $Mnombre,
        $edad,
        $cedula
    );

    $persona->setCedula("58472910");
    
    echo $persona->saludar();
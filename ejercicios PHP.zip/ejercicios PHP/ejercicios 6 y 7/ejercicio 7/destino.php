<?php
 if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $numeros = $_POST['numeros'];

    if (!empty($numeros)) {
        $maximo = max($numeros);
        echo "El número máximo es: $maximo<br>";

    } else {
        echo "No se han ingresado números.";
    }
 }


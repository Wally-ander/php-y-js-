<?php

function esEntero($valor) {
    return filter_var($valor, FILTER_VALIDATE_INT) !== false;
}

function esPar($valor) {
    return $valor % 2 === 0;
}


$usuario = $_GET['usuario'];

if (esEntero($usuario)) {
    $paridad = esPar($usuario) ? "par" : "impar";
    echo "El número $usuario es entero y es $paridad.";
} else {
    echo "El valor $usuario no es un número entero.";
}

<?php

    $nombres = $_POST['nombres'];
    $edades = $_POST['edades'];


    $personas = [];

    for ($i = 0; $i < count($nombres); $i++) {
        $nombre = trim($nombres[$i]);
        $edad = (int) ($edades[$i]);
        $personas[$nombre] = $edad;
    }


    echo "<h2>Personas mayores de 18 años</h2>";

    foreach ($personas as $nombre => $edad) {
        if ($edad >= 18) {
            echo "- $nombre tiene $edad años</p>";
        }
    }
?>
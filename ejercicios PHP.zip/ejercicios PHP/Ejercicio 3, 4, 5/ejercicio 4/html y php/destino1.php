<?php

$nombres = $_POST['nombres'];   
$edades = $_POST['edades'];

$personas = [];

for ($i = 0; $i < count($nombres); $i++) {
    $nombre = trim($nombres[$i]);
    $edad = (int) $edades[$i];
    if ($nombre !== "") {
        $personas[$nombre] = $edad;
    }
}

echo "<h1>Lista de personas mayores de 18 años</h1>";

foreach ($personas as $nombre => $edad) {
    if ($edad >= 18) {
        echo "<p>$nombre: $edad años</p>";
    }
}
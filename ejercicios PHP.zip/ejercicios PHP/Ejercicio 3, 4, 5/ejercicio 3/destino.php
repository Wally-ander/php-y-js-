<?php
if ($_SERVER["REQUEST_METHOD"] == "GET") {
    // Recibe los datos enviados desde el formulario
    $datos = $_POST["datos"];

    // Convierte cada dato a mayúsculas y los asigna a variables individuales
    $dato1 = strtoupper($datos[0]);
    $dato2 = strtoupper($datos[1]);
    $dato3 = strtoupper($datos[2]);
    $dato4 = strtoupper($datos[3]);
    $dato5 = strtoupper($datos[4]); 

    // Muestra los datos en mayúsculas
    echo "<h3>Datos en mayúsculas:</h3>";
    echo "Dato 1: $dato1<br>";
    echo "Dato 2: $dato2<br>";
    echo "Dato 3: $dato3<br>";
    echo "Dato 4: $dato4<br>";
    echo "Dato 5: $dato5<br>";
}
?>
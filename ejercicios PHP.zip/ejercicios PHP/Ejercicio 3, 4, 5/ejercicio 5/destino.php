<?php
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Verifica si el formulario fue enviado
    $nombres = $_POST['nombres'];
    $precios = $_POST['precios'];
    $stock = $_POST['stocks'];
}


$productos = [];

for ($i = 0; $i < count($nombres); $i++) {
    $productos[$i] = [
        'nombre' => trim($nombres[$i]),
        'precio' => (float)$precios[$i],
        'stock' => (int)$stock[$i]
    ];
}


echo "<h1>Productos disponibles a menos de $50 y Stock mayor a 0</h1>";

foreach ($productos as $producto) {
    if ($producto["stock"] > 0 && $producto["precio"] < 50 ) {
        echo "{$producto['nombre']} (Precio: {$producto['precio']}, Stock: {$producto['stock']})<br>";
    }
}
?>
<?php
    $archivo = fopen('tareas.txt', 'r'); // Abrir el archivo en modo lectura
    if ($archivo) {
        while (($linea = fgets($archivo)) !== false) {
            echo $linea . "<br>"; // Mostrar cada línea del archivo
        }
        fclose($archivo); // Cerrar el archivo
    } else {
        echo "Error al abrir el archivo.<br>";
    }
<?php
    $tarea = $_POST['tarea'];
    $fecha = $_POST['fecha'];
    if (isset($_POST['tipo'])) {
        $tipo = $_POST['tipo'];
    } else {
        echo "No se ha seleccionado un tipo de tarea.<br>";
    }

    $archivo = fopen('tareas.txt', 'a+'); 

    if ($archivo) {
        $contenido = "Tarea: $tarea\n Fecha: $fecha\nTipo: $tipo\n\n";
        fwrite($archivo, $contenido); // Escribir en el archivo
        fclose($archivo); // Cerrar el archivo
        
        echo "Tarea guardada correctamente.<br>";
    } else {
        echo "Error al abrir el archivo.<br>";
    }

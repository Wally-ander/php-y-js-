<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Recibimos los datos del formulario
    $nombre = $_POST['nombre'];
    $edad = $_POST['edad'];
    $cedula = $_POST['cedula'];
    $curso = $_POST['curso'];
        
    $Mnombre = ucfirst($nombre); // Capitalizamos el nombre

    // Clase Persona
    class Persona {
        public $nombre;
        public $edad;
        private $cedula;

        public function __construct($nombre, $edad, $cedula) {
            $this->nombre = $nombre;
            $this->edad = $edad;
            $this->cedula = $cedula;
        }

        public function saludar() {
            return "Hola, mi nombre es " . $this->nombre . ", tengo " . $this->edad . " años y mi cédula es " . $this->cedula . ".";
        }
    }

    // Clase Estudiante que hereda de Persona
    class Estudiante extends Persona {
        public $curso;

        public function __construct($nombre, $edad, $cedula, $curso) {
            parent::__construct($nombre, $edad, $cedula); // Llamada al constructor de la clase Persona
            $this->curso = $curso;
        }

        public function saludar() {
            return parent::saludar() . " Estoy estudiando en el curso " . $this->curso . ".";
        }
    }

    // Crear un objeto de la clase Estudiante
    $estudiante = new Estudiante($Mnombre, $edad, $cedula, $curso);

    // Mostrar la información del estudiante
    echo $estudiante->saludar();
}
?>

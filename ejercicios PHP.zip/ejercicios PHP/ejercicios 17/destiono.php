<?php
    $nombre = $_POST['nombre'];
    $correo = $_POST['correo'];

    function validarCorreo($correo) {
        return filter_var($correo, FILTER_VALIDATE_EMAIL) !== false;
    } 

    if (validarCorreo($correo)) {
        echo "El correo es válido.";
    } else {
        echo "El correo no es válido.";
    }

    // Filtra y valida que el correo sea una dirección válida.
    // El filtro FILTER_VALIDATE_EMAIL realiza una validación básica según la estructura del correo electrónico:
    // - Verifica que el correo contenga el símbolo '@' seguido de un dominio.
    // - Verifica que el dominio tenga al menos un punto (.) y un dominio válido (ejemplo.com).
    // - No valida si el dominio existe realmente, solo la estructura básica.
    // - No verifica si la dirección de correo electrónico realmente está registrada o si el dominio tiene un servidor de correo.
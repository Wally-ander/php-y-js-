<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Recibimos los datos del formulario
    $nombre = $_POST['nombre'];
    $edad = $_POST['edad'];
    $cedula = $_POST['cedula'];
    $curso = $_POST['curso'];
        
    $Mnombre = ucfirst($nombre); // Capitalizamos el nombre

    // Clase Persona
    class Persona {
        public $nombre;
        public $edad;
        protected $cedula;

        public function __construct($nombre, $edad, $cedula) {
            $this->nombre = $nombre;
            $this->edad = $edad;
            $this->cedula = $cedula;
        }

        public function getCedula() {
            return $this->cedula;
        }
    }

    // Clase Estudiante que hereda de Persona
    class Estudiante extends Persona {
        public $curso;

        public function __construct($nombre, $edad, $cedula, $curso) {
            parent::__construct($nombre, $edad, $cedula); // Llamada al constructor de la clase Persona
            $this->curso = $curso;
        }
    }

    // Crear un objeto de la clase Estudiante
    $estudiante = new Estudiante($Mnombre, $edad, $cedula, $curso);

    // Limpiar el archivo antes de escribir nuevos datos
    file_put_contents('datos.txt', ''); // Esto borra el contenido del archivo

    // Escribir los nuevos datos
    $datos = "Nombre: " . $estudiante->nombre . "\n";
    $datos .= "Edad: " . $estudiante->edad . "\n";
    $datos .= "Cédula: " . $estudiante->getCedula() . "\n";
    $datos .= "Curso: " . $estudiante->curso . "\n";

    // Escribir los datos al archivo
    file_put_contents('datos.txt', $datos);

    echo "Los datos han sido guardados correctamente.<br>";

    // Leer y mostrar los datos guardados
    $contenido = file_get_contents('datos.txt');
    echo "<h2>Datos guardados:</h2><pre>$contenido</pre>";
}
?>

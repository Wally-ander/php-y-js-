<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $cedulaEliminar = $_POST['cedula'];

    // Leer el archivo usuarios.txt
    $usuarios = file('usuarios.txt');
    $nuevoContenido = [];

    // Buscar la línea con la cédula a eliminar
    foreach ($usuarios as $usuario) {
        if (strpos($usuario, $cedulaEliminar) === false) {
            $nuevoContenido[] = $usuario;
        }
    }

    // Reescribir el archivo sin la línea eliminada
    file_put_contents('usuarios.txt', implode("", $nuevoContenido));

    echo "Usuario eliminado correctamente.";
}
?>

<form method="post">
    <label for="cedula">Cédula a eliminar:</label>
    <input type="text" id="cedula" name="cedula" required><br><br>
    <input type="submit" value="Eliminar Usuario">
</form>

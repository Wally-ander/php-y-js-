<?php
// Abrir el archivo usuarios.txt en modo lectura
$archivo = fopen('usuarios.txt', 'r');

if ($archivo) {
    echo "<h2>Usuarios Registrados:</h2>";
    echo "<ul>";  // Abrir la lista desordenada

    // Leer cada línea del archivo
    while (($linea = fgets($archivo)) !== false) {
        // Separar los datos de cada usuario usando el delimitador "|"
        $usuario = explode("| ", $linea);

        // Mostrar los datos del usuario
        echo "<li>";
        echo "Nombre: " . $usuario[0] . " - Edad: " . $usuario[1] . " - Cédula: " . $usuario[2] . " - Curso: " . $usuario[3];
        
        // Botón para eliminar el usuario (pasando la cédula en la URL)
        echo ' <a href="eliminar.php?cedula=' . $usuario[2] . '"><button>Eliminar</button></a>';
        echo "</li>";
    }
    echo "</ul>";  // Cerrar la lista desordenada

    fclose($archivo);  // Cerrar el archivo
} else {
    echo "Error al abrir el archivo.<br>";
}
?>

<!-- Botón para regresar a la página principal (opcional) -->
<a href="index.html"><button>Volver al Formulario</button></a>

<?php
// Verificar si se envió el formulario mediante POST
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Recibimos los datos del formulario
    $nombre = $_POST['nombre'];
    $edad = $_POST['edad'];
    $cedula = $_POST['cedula'];
    $curso = $_POST['curso'];

    // Capitalizamos el nombre y el curso
    $Mnombre = ucfirst(strtolower($nombre));
    $Mcurso = ucfirst(strtolower($curso));

    // Validar que los campos no estén vacíos
    if (empty($nombre) || empty($edad) || empty($cedula) || empty($curso)) {
        echo "Todos los campos son requeridos.";
    } else {
        // Abrir el archivo usuarios.txt en modo append (agregar al final)
        $archivo = fopen("usuarios.txt", "a+");

        if ($archivo) {
            // Creamos el registro como una línea con los datos del usuario
            $registro = [$Mnombre, $edad, $cedula, $Mcurso];
            // Convertimos el array en una cadena con los datos separados por "|"
            $linea = implode("| ", $registro) . PHP_EOL;
            
            // Escribimos la línea en el archivo
            fwrite($archivo, $linea);

            // Cerramos el archivo
            fclose($archivo);

            // Mostrar mensaje de éxito y un botón para ir a la página de lectura
            echo "Usuario registrado correctamente.<br>";
            echo '<a href="leer.php"><button>Ver Usuarios Registrados</button></a>';
        } else {
            echo "Error al abrir el archivo.<br>";
        }
    }
}
?>
